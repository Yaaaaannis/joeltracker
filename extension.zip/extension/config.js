// Remplacez ces valeurs par vos propres identifiants Twitch
const TWITCH_CLIENT_ID = 'VOTRE_CLIENT_ID';
const TWITCH_CLIENT_SECRET = 'VOTRE_CLIENT_SECRET';

// Exporter les constantes pour une utilisation dans d'autres fichiers
export { TWITCH_CLIENT_ID, TWITCH_CLIENT_SECRET }; 